(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,90599,e=>{"use strict";var r=e.i(43476),t=e.i(71645),a=e.i(18566),o=e.i(54858);let i=[{code:"+353",flag:"🇮🇪",country:"Ireland"},{code:"+1",flag:"🇺🇸",country:"USA"},{code:"+44",flag:"🇬🇧",country:"UK"},{code:"+91",flag:"🇮🇳",country:"India"},{code:"+61",flag:"🇦🇺",country:"Australia"},{code:"+1",flag:"🇨🇦",country:"Canada"},{code:"+49",flag:"🇩🇪",country:"Germany"},{code:"+33",flag:"🇫🇷",country:"France"},{code:"+39",flag:"🇮🇹",country:"Italy"},{code:"+34",flag:"🇪🇸",country:"Spain"},{code:"+351",flag:"🇵🇹",country:"Portugal"},{code:"+31",flag:"🇳🇱",country:"Netherlands"},{code:"+32",flag:"🇧🇪",country:"Belgium"},{code:"+41",flag:"🇨🇭",country:"Switzerland"},{code:"+43",flag:"🇦🇹",country:"Austria"},{code:"+46",flag:"🇸🇪",country:"Sweden"},{code:"+47",flag:"🇳🇴",country:"Norway"},{code:"+45",flag:"🇩🇰",country:"Denmark"},{code:"+358",flag:"🇫🇮",country:"Finland"},{code:"+48",flag:"🇵🇱",country:"Poland"},{code:"+971",flag:"🇦🇪",country:"UAE"},{code:"+966",flag:"🇸🇦",country:"Saudi Arabia"},{code:"+65",flag:"🇸🇬",country:"Singapore"},{code:"+64",flag:"🇳🇿",country:"New Zealand"}];e.s(["default",0,function(){let e=(0,a.useRouter)(),[n,s]=(0,t.useState)(""),[d,l]=(0,t.useState)(""),[c,m]=(0,t.useState)(""),[f,p]=(0,t.useState)(!1),[u,g]=(0,t.useState)("login"),[h,x]=(0,t.useState)("phone"),[b,v]=(0,t.useState)("+353"),[y,j]=(0,t.useState)(""),[w,k]=(0,t.useState)(""),[N,S]=(0,t.useState)(""),[P,C]=(0,t.useState)(""),[T,z]=(0,t.useState)(""),[O,F]=(0,t.useState)(""),[_,I]=(0,t.useState)(""),[A,E]=(0,t.useState)(""),[D,R]=(0,t.useState)(""),[B,q]=(0,t.useState)(!1),U=()=>{g("login"),E(""),R(""),C(""),z(""),F(""),I("")},L=async r=>{r.preventDefault(),m(""),p(!0);try{let r=await fetch(`${o.API_BASE_URL}/api/driver/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:n.trim(),password:d})});if(!r.ok){let e=await r.text(),t=e;try{t=JSON.parse(e).message||e}catch(e){}throw Error(t||"Invalid credentials")}let t=await r.json();localStorage.setItem("driver_token",t.token||t.accessToken||"driver_session"),localStorage.setItem("driver_name",t.name||t.driverName||n.split("@")[0]),localStorage.setItem("driver_email",n),e.push("/driver/dashboard")}catch(e){m(e.message||"Login failed. Please check your credentials.")}finally{p(!1)}},$=async e=>{e&&e.preventDefault(),E(""),R("");let r="";if("phone"===h){let e=y.trim();if(!e)return void E("Please enter your mobile phone number.");r=e.startsWith("+")?e:`${b}${e}`}else if(!(r=w.trim()))return void E("Please enter your registered email address.");q(!0);try{let e=await fetch(`${o.API_BASE_URL}/api/driver/forgot-password`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({identifier:r})}),t=await e.text(),a={};try{a=JSON.parse(t)}catch(e){}if(!e.ok)throw Error(a.message||t||"Failed to send verification OTP.");S(r),R(a.message||`OTP sent to ${r}. Please check your inbox or SMS.`),g("forgot_verify")}catch(e){E(e.message||"Failed to send OTP. Please try again.")}finally{q(!1)}},J=async e=>{e.preventDefault(),E(""),R("");let r=P.trim();if(!r)return void E("Please enter the OTP code received.");q(!0);try{let e=await fetch(`${o.API_BASE_URL}/api/driver/verify-otp`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({identifier:N,otp:r})}),t=await e.text(),a={};try{a=JSON.parse(t)}catch(e){}if(!e.ok)throw Error(a.message||t||"Invalid or expired OTP code.");let i=a.resetToken||a.token||a.reset_token||("string"==typeof a?a:"");if(!i)throw Error(a.message||"OTP verification succeeded but no reset token was returned.");z(i),R("Code verified successfully. Now create your new password."),g("forgot_reset")}catch(e){E(e.message||"OTP verification failed. Please try again.")}finally{q(!1)}},M=async e=>{if(e.preventDefault(),E(""),R(""),O.length<6)return void E("Password must be at least 6 characters long.");if(O!==_)return void E("Passwords do not match. Please re-enter.");q(!0);try{let e=await fetch(`${o.API_BASE_URL}/api/driver/reset-password`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({identifier:N,resetToken:T,newPassword:O})}),r=await e.text(),t={};try{t=JSON.parse(r)}catch(e){}if(!e.ok)throw Error(t.message||r||"Failed to reset password.");g("forgot_success"),N.includes("@")&&s(N)}catch(e){E(e.message||"Failed to update password. Please try again.")}finally{q(!1)}};return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)("style",{children:`
        .driver-page {
          min-height: 100vh;
          padding-top: 90px;
          box-sizing: border-box;
          background-color: var(--bg);
          font-family: var(--font-outfit), sans-serif;
          color: var(--text);
        }
        .driver-inner {
          max-width: 1200px;
          margin: 0 auto;
          padding: 3rem 1.5rem;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 4rem;
          align-items: center;
        }
        @media (max-width: 900px) {
          .driver-inner { grid-template-columns: 1fr; gap: 2rem; }
        }

        /* LEFT: SEO / marketing */
        .driver-left { padding-top: 1rem; }
        .driver-badge {
          display: inline-flex; align-items: center; gap: 8px;
          background: var(--primary-light); border: 1px solid var(--border-dark);
          color: var(--primary); padding: 6px 16px; border-radius: 50px;
          font-size: 0.78rem; font-weight: 700; letter-spacing: 1.5px;
          text-transform: uppercase; margin-bottom: 1.5rem;
        }
        .driver-left h1 {
          font-family: var(--font-playfair), serif;
          font-size: clamp(2.5rem, 4.5vw, 3.5rem);
          font-weight: 500; line-height: 1.15;
          margin: 0 0 1rem 0;
          color: var(--text);
          letter-spacing: 0.02em;
        }
        .driver-left p {
          color: var(--text-muted); font-size: 1.05rem; line-height: 1.7;
          margin: 0 0 2.5rem 0;
          font-weight: 300;
        }
        
        .perks-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .perk {
          background: var(--card-bg);
          border: 1px solid var(--border);
          box-shadow: var(--card-shadow);
          border-radius: 14px; padding: 1.25rem 1.1rem;
          transition: all 0.2s;
        }
        .perk:hover { border-color: var(--primary); transform: translateY(-2px); }
        .perk-icon { font-size: 1.5rem; margin-bottom: 8px; display: block; color: var(--primary); }
        .perk h3 { font-size: 0.95rem; font-weight: 600; margin: 0 0 4px; color: var(--text); }
        .perk p { font-size: 0.85rem; color: var(--text-muted); margin: 0; line-height: 1.5; font-weight: 300; }

        /* RIGHT: Form card */
        .driver-card {
          background: var(--card-bg);
          border: 1px solid var(--border);
          border-radius: 24px;
          padding: 3rem 2.5rem;
          box-shadow: 0 10px 40px rgba(0,0,0,0.04);
          max-width: 480px;
          margin: 0 auto;
          width: 100%;
          box-sizing: border-box;
        }
        .card-logo { display: flex; justify-content: center; margin-bottom: 1.5rem; }
        .card-logo img { height: 52px; object-fit: contain; }
        .card-title { text-align: center; margin-bottom: 2rem; }
        .card-title h2 { font-family: var(--font-playfair), serif; font-size: 1.8rem; font-weight: 500; margin: 0 0 4px; color: var(--text); }
        .card-title p { font-size: 0.85rem; color: var(--text-muted); margin: 0; font-weight: 300; }

        .method-tabs {
          display: flex;
          background: #f1f5f9;
          border-radius: 8px;
          padding: 4px;
          margin-bottom: 1.5rem;
          gap: 4px;
        }
        .method-tab {
          flex: 1;
          padding: 8px 12px;
          border: none;
          background: transparent;
          font-size: 0.82rem;
          font-weight: 600;
          color: var(--text-muted);
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.2s;
          font-family: var(--font-outfit), sans-serif;
        }
        .method-tab.active {
          background: #ffffff;
          color: var(--primary);
          box-shadow: 0 2px 6px rgba(0,0,0,0.06);
        }

        .field { display: flex; flex-direction: column; gap: 8px; margin-bottom: 1.25rem; }
        .field label {
          font-size: 0.72rem; font-weight: 600; color: var(--text-muted);
          text-transform: uppercase; letter-spacing: 1.5px;
        }
        .field input, .field select {
          background: #FFFFFF;
          border: 1px solid var(--border-input);
          color: var(--text); padding: 0.9rem 1rem;
          border-radius: 6px; font-size: 1rem; font-family: var(--font-outfit), sans-serif;
          transition: all 0.3s ease; outline: none; width: 100%; box-sizing: border-box;
        }
        .field input::placeholder { color: var(--text-muted); opacity: 0.7; }
        .field input:focus, .field select:focus {
          border-color: var(--primary); box-shadow: inset 0 2px 4px rgba(0,0,0,0.05), 0 0 0 1px var(--primary);
        }

        .otp-input {
          letter-spacing: 6px;
          text-align: center;
          font-size: 1.35rem !important;
          font-weight: 700;
        }

        .error-box {
          background: #fff1f2; border: 1px solid #fecdd3;
          color: #e11d48; padding: 0.8rem 1rem; border-radius: 6px;
          font-size: 0.85rem; margin-bottom: 1.25rem; text-align: center; font-family: var(--font-outfit), sans-serif;
        }
        .info-box {
          background: #f0fdf4; border: 1px solid #bbf7d0;
          color: #166534; padding: 0.8rem 1rem; border-radius: 6px;
          font-size: 0.85rem; margin-bottom: 1.25rem; text-align: center; font-family: var(--font-outfit), sans-serif;
        }

        .btn-action {
          width: 100%; padding: 1.1rem;
          background: var(--primary);
          color: #FFFFFF; font-weight: 600; font-size: 0.95rem;
          border: 1px solid transparent; border-radius: 4px; cursor: pointer;
          letter-spacing: 2.5px; text-transform: uppercase; margin-top: 0.5rem;
          transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
          font-family: var(--font-outfit), sans-serif;
        }
        .btn-action:hover:not(:disabled) {
          background: var(--primary-hover);
        }
        .btn-action:disabled { opacity: 0.6; cursor: not-allowed; }

        .forgot-link-wrap {
          display: flex;
          justify-content: flex-end;
          margin-top: -0.5rem;
          margin-bottom: 1.25rem;
        }
        .forgot-btn {
          background: none;
          border: none;
          color: var(--primary);
          font-size: 0.85rem;
          cursor: pointer;
          font-weight: 500;
          padding: 0;
          text-decoration: underline;
          font-family: var(--font-outfit), sans-serif;
        }
        .forgot-btn:hover { color: var(--primary-hover); }

        .form-footer-links {
          margin-top: 1.5rem;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 0.75rem;
          font-size: 0.88rem;
          color: var(--text-muted);
        }
        .form-footer-links a, .form-footer-links button {
          color: var(--primary);
          font-weight: 600;
          text-decoration: none;
          background: none;
          border: none;
          cursor: pointer;
          padding: 0;
          font-size: 0.88rem;
          font-family: var(--font-outfit), sans-serif;
        }
        .form-footer-links a:hover, .form-footer-links button:hover {
          text-decoration: underline;
          color: var(--primary-hover);
        }

        .success-box {
          text-align: center;
          padding: 1rem 0;
        }
        .success-icon {
          font-size: 3rem;
          margin-bottom: 1rem;
          display: block;
        }

        /* SEO keywords section at bottom */
        .seo-footer {
          max-width: 1200px; margin: 3rem auto 0; padding: 0 1.5rem 3rem;
        }
        .seo-footer h2 {
          font-family: var(--font-playfair), serif;
          font-size: 1.5rem; font-weight: 500; color: var(--text);
          margin-bottom: 1.25rem;
        }
        .seo-tags { display: flex; flex-wrap: wrap; gap: 0.75rem; }
        .seo-tag {
          background: #fff; border: 1px solid var(--border);
          color: var(--text-muted); padding: 6px 16px; border-radius: 50px;
          font-size: 0.8rem; font-weight: 400; transition: all 0.3s;
        }
        .seo-tag:hover { border-color: var(--primary); color: var(--primary); }
      `}),(0,r.jsxs)("div",{className:"driver-page",children:[(0,r.jsxs)("div",{className:"driver-inner",children:[(0,r.jsxs)("div",{className:"driver-left",children:[(0,r.jsx)("div",{className:"driver-badge",children:"🔒 Secure Access"}),(0,r.jsxs)("h1",{children:["Driver Dashboard",(0,r.jsx)("br",{}),"Portal"]}),(0,r.jsx)("p",{children:"Welcome to Private Transfers Ireland. Access your driver dashboard to view your schedule, manage your upcoming airport and city transfers, and track your revenue."}),(0,r.jsx)("div",{className:"perks-grid",children:[{icon:"📱",title:"Manage Bookings",desc:"View and accept new private transfer requests instantly."},{icon:"📅",title:"Schedule Control",desc:"See all your upcoming going and return trips at a glance."},{icon:"💶",title:"Track Earnings",desc:"Monitor your completed rides and track your revenue."},{icon:"🗺️",title:"Route Details",desc:"Access full pickup, dropoff, and flight information."}].map((e,t)=>(0,r.jsxs)("div",{className:"perk",children:[(0,r.jsx)("span",{className:"perk-icon",children:e.icon}),(0,r.jsx)("h3",{children:e.title}),(0,r.jsx)("p",{children:e.desc})]},t))})]}),(0,r.jsxs)("div",{className:"driver-card",children:[(0,r.jsx)("div",{className:"card-logo",children:(0,r.jsx)("img",{src:"/logo.png",alt:"Private Transfers Ireland"})}),"login"===u&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("div",{className:"card-title",children:[(0,r.jsx)("h2",{children:"Welcome Back"}),(0,r.jsx)("p",{children:"Enter your credentials to access your account"})]}),c&&(0,r.jsxs)("div",{className:"error-box",children:["⚠️ ",c]}),(0,r.jsxs)("form",{onSubmit:L,children:[(0,r.jsxs)("div",{className:"field",children:[(0,r.jsx)("label",{children:"Email Address"}),(0,r.jsx)("input",{type:"email",value:n,onChange:e=>s(e.target.value),placeholder:"",required:!0,autoComplete:"off"})]}),(0,r.jsxs)("div",{className:"field",children:[(0,r.jsx)("label",{children:"Password"}),(0,r.jsx)("input",{type:"password",value:d,onChange:e=>l(e.target.value),placeholder:"",required:!0,autoComplete:"current-password"})]}),(0,r.jsx)("div",{className:"forgot-link-wrap",children:(0,r.jsx)("button",{type:"button",className:"forgot-btn",onClick:()=>{E(""),R(""),g("forgot_request")},children:"Forgot password?"})}),(0,r.jsx)("button",{type:"submit",className:"btn-action",disabled:f,children:f?"Authenticating...":"Sign In →"}),(0,r.jsx)("div",{className:"form-footer-links",children:(0,r.jsxs)("span",{children:["Not registered yet?"," ",(0,r.jsx)("a",{href:"/driver/register",children:"Register as Driver"})]})})]})]}),"forgot_request"===u&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("div",{className:"card-title",children:[(0,r.jsx)("h2",{children:"Forgot Password"}),(0,r.jsx)("p",{children:"Choose your verification method to reset password"})]}),(0,r.jsxs)("div",{className:"method-tabs",children:[(0,r.jsx)("button",{type:"button",className:`method-tab ${"phone"===h?"active":""}`,onClick:()=>{x("phone"),E("")},children:"📱 Mobile Number"}),(0,r.jsx)("button",{type:"button",className:`method-tab ${"email"===h?"active":""}`,onClick:()=>{x("email"),E("")},children:"✉️ Email Address"})]}),A&&(0,r.jsxs)("div",{className:"error-box",children:["⚠️ ",A]}),(0,r.jsxs)("form",{onSubmit:$,children:["phone"===h?(0,r.jsxs)("div",{className:"field",children:[(0,r.jsx)("label",{children:"Mobile Number"}),(0,r.jsxs)("div",{style:{display:"flex",gap:"0.5rem"},children:[(0,r.jsx)("select",{value:b,onChange:e=>v(e.target.value),style:{padding:"0.85rem 0.5rem",borderRadius:"6px",border:"1px solid var(--border-input)",background:"#fff",width:"120px",fontSize:"0.9rem"},children:i.map(e=>(0,r.jsxs)("option",{value:e.code,children:[e.flag," ",e.code]},e.country+e.code))}),(0,r.jsx)("input",{type:"tel",value:y,onChange:e=>j(e.target.value),placeholder:"",required:!0,style:{flex:1}})]})]}):(0,r.jsxs)("div",{className:"field",children:[(0,r.jsx)("label",{children:"Registered Email"}),(0,r.jsx)("input",{type:"email",value:w,onChange:e=>k(e.target.value),placeholder:"",required:!0,autoComplete:"email"})]}),(0,r.jsx)("button",{type:"submit",className:"btn-action",disabled:B,children:B?"Sending OTP...":"Send OTP Code →"}),(0,r.jsx)("div",{className:"form-footer-links",children:(0,r.jsx)("button",{type:"button",onClick:U,children:"← Back to Sign In"})})]})]}),"forgot_verify"===u&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("div",{className:"card-title",children:[(0,r.jsx)("h2",{children:"Verify OTP"}),(0,r.jsxs)("p",{children:["Enter verification code sent to ",(0,r.jsx)("br",{}),(0,r.jsx)("strong",{style:{color:"var(--text)"},children:N})]})]}),D&&(0,r.jsxs)("div",{className:"info-box",children:["✓ ",D]}),A&&(0,r.jsxs)("div",{className:"error-box",children:["⚠️ ",A]}),(0,r.jsxs)("form",{onSubmit:J,children:[(0,r.jsxs)("div",{className:"field",children:[(0,r.jsx)("label",{children:"6-Digit OTP Code"}),(0,r.jsx)("input",{type:"text",inputMode:"numeric",maxLength:6,className:"otp-input",value:P,onChange:e=>C(e.target.value),placeholder:"",required:!0,autoComplete:"one-time-code"})]}),(0,r.jsx)("button",{type:"submit",className:"btn-action",disabled:B,children:B?"Verifying...":"Verify OTP →"}),(0,r.jsxs)("div",{className:"form-footer-links",children:[(0,r.jsx)("button",{type:"button",disabled:B,onClick:()=>$(),style:{fontSize:"0.85rem"},children:"Didn't receive code? Resend OTP"}),(0,r.jsx)("button",{type:"button",onClick:()=>{E(""),g("forgot_request")},style:{fontSize:"0.82rem",color:"var(--text-muted)"},children:"Change phone number or email"}),(0,r.jsx)("button",{type:"button",onClick:U,children:"← Back to Sign In"})]})]})]}),"forgot_reset"===u&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("div",{className:"card-title",children:[(0,r.jsx)("h2",{children:"Create New Password"}),(0,r.jsx)("p",{children:"Enter a secure new password for your account"})]}),D&&(0,r.jsxs)("div",{className:"info-box",children:["✓ ",D]}),A&&(0,r.jsxs)("div",{className:"error-box",children:["⚠️ ",A]}),(0,r.jsxs)("form",{onSubmit:M,children:[(0,r.jsxs)("div",{className:"field",children:[(0,r.jsx)("label",{children:"New Password"}),(0,r.jsx)("input",{type:"password",value:O,onChange:e=>F(e.target.value),placeholder:"",required:!0,minLength:6,autoComplete:"new-password"})]}),(0,r.jsxs)("div",{className:"field",children:[(0,r.jsx)("label",{children:"Confirm New Password"}),(0,r.jsx)("input",{type:"password",value:_,onChange:e=>I(e.target.value),placeholder:"",required:!0,minLength:6,autoComplete:"new-password"})]}),(0,r.jsx)("button",{type:"submit",className:"btn-action",disabled:B,children:B?"Updating Password...":"Reset Password →"}),(0,r.jsx)("div",{className:"form-footer-links",children:(0,r.jsx)("button",{type:"button",onClick:U,children:"← Back to Sign In"})})]})]}),"forgot_success"===u&&(0,r.jsxs)("div",{className:"success-box",children:[(0,r.jsx)("span",{className:"success-icon",children:"🎉"}),(0,r.jsxs)("div",{className:"card-title",children:[(0,r.jsx)("h2",{children:"Password Reset Complete!"}),(0,r.jsx)("p",{children:"Your password has been successfully updated. You can now log in with your new credentials."})]}),(0,r.jsx)("button",{type:"button",className:"btn-action",onClick:U,children:"Sign In With New Password →"})]})]})]}),(0,r.jsxs)("div",{className:"seo-footer",children:[(0,r.jsx)("h2",{children:"Chauffeur & Driver Portal Ireland"}),(0,r.jsx)("div",{className:"seo-tags",children:["Driver login Ireland","Chauffeur portal","Private transfer driver login","Manage bookings driver","Driver dashboard Ireland","Private hire portal","Executive driver login","Dublin chauffeur login","Airport transfer driver access","Driver partner login","Chauffeur schedule manager"].map(e=>(0,r.jsx)("span",{className:"seo-tag",children:e},e))})]})]})]})}])}]);